﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ConfigPath = Join-Path $ScriptDir "helios_positions.json"
$ProtocolUrl = if ($args.Count -gt 0) { [string]$args[0] } else { "" }
$InitialMenu = "sales"
$InitialMonth = (Get-Date).ToString("MM")

if ($ProtocolUrl) {
  $decodedUrl = [Uri]::UnescapeDataString($ProtocolUrl)
  if ($decodedUrl -match "menu=([^&]+)") { $InitialMenu = $Matches[1] }
  if ($decodedUrl -match "month=([0-9]{1,2})") { $InitialMonth = ("{0:D2}" -f [int]$Matches[1]) }
}

Add-Type @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public class WinApi {
  public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int X, int Y);
  [DllImport("user32.dll")] public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
}
"@

$MOUSEEVENTF_LEFTDOWN = 0x0002
$MOUSEEVENTF_LEFTUP = 0x0004
$MOUSEEVENTF_RIGHTDOWN = 0x0008
$MOUSEEVENTF_RIGHTUP = 0x0010

function New-DefaultConfig {
  @{
    monthStart = @{ x = 160; y = 160 }
    monthEnd = @{ x = 215; y = 160 }
    deptBlank = @{ x = 610; y = 134 }
    deptSearch = @{ x = 793; y = 134 }
    deptFirstCheck = @{ x = 45; y = 105 }
    deptPopupClose = @{ x = 292; y = 88 }
    search = @{ x = 1460; y = 90 }
    grid = @{ x = 430; y = 610 }
    exportOrg = @{ x = 480; y = 612 }
  }
}

function Load-Config {
  $defaults = New-DefaultConfig
  if (Test-Path $ConfigPath) {
    try {
      $raw = Get-Content $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
      $saved = @{}
      foreach ($prop in $raw.PSObject.Properties) {
        $saved[$prop.Name] = @{ x = [int]$prop.Value.x; y = [int]$prop.Value.y }
      }
      foreach ($key in $defaults.Keys) {
        if (-not $saved.ContainsKey($key)) { $saved[$key] = $defaults[$key] }
      }
      return $saved
    } catch {}
  }
  return $defaults
}

function Save-Config($config) {
  $config | ConvertTo-Json -Depth 4 | Set-Content -Path $ConfigPath -Encoding UTF8
}

function Menu-Key {
  if ($menuBox -and $menuBox.SelectedItem -eq "매출(기타)") { return "other" }
  return "sales"
}

function Config-Key($menu, $key) {
  return "${menu}_${key}"
}

function Get-Pos($menu, $key) {
  $specificKey = Config-Key $menu $key
  if ($config.ContainsKey($specificKey)) { return $config[$specificKey] }
  return $config[$key]
}

function Set-Pos($menu, $key, $value) {
  $specificKey = Config-Key $menu $key
  $config[$specificKey] = $value
  Save-Config $config
}

function Get-HeliosWindow {
  $proc = Get-Process -Name "MiPlatform320U" -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $proc) { throw "HELIOS(MiPlatform320U) 프로그램을 찾지 못했습니다. 먼저 HELIOS를 실행해주세요." }

  $handles = New-Object System.Collections.Generic.List[System.IntPtr]
  $callback = [WinApi+EnumWindowsProc]{
    param([IntPtr]$hWnd, [IntPtr]$lParam)
    [uint32]$windowProcessId = 0
    [WinApi]::GetWindowThreadProcessId($hWnd, [ref]$windowProcessId) | Out-Null
    if ($windowProcessId -eq [uint32]$proc.Id -and [WinApi]::IsWindowVisible($hWnd)) {
      $handles.Add($hWnd)
    }
    return $true
  }
  [WinApi]::EnumWindows($callback, [IntPtr]::Zero) | Out-Null
  if ($handles.Count -eq 0) {
    if ($proc.MainWindowHandle -ne 0) { return $proc.MainWindowHandle }
    throw "HELIOS 창 핸들을 찾지 못했습니다. HELIOS 화면이 최소화되어 있으면 복원해주세요."
  }
  return $handles[0]
}

function Focus-Helios {
  $hWnd = Get-HeliosWindow
  [WinApi]::ShowWindow($hWnd, 9) | Out-Null
  Start-Sleep -Milliseconds 250
  [WinApi]::SetForegroundWindow($hWnd) | Out-Null
  Start-Sleep -Milliseconds 350
  return $hWnd
}

function Get-WindowRect($hWnd) {
  $rect = New-Object WinApi+RECT
  [WinApi]::GetWindowRect($hWnd, [ref]$rect) | Out-Null
  return $rect
}

function Click-At($x, $y, [switch]$Right) {
  [WinApi]::SetCursorPos([int]$x, [int]$y) | Out-Null
  Start-Sleep -Milliseconds 120
  if ($Right) {
    [WinApi]::mouse_event($MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, [UIntPtr]::Zero)
    [WinApi]::mouse_event($MOUSEEVENTF_RIGHTUP, 0, 0, 0, [UIntPtr]::Zero)
  } else {
    [WinApi]::mouse_event($MOUSEEVENTF_LEFTDOWN, 0, 0, 0, [UIntPtr]::Zero)
    [WinApi]::mouse_event($MOUSEEVENTF_LEFTUP, 0, 0, 0, [UIntPtr]::Zero)
  }
  Start-Sleep -Milliseconds 180
}

function Click-Rel($hWnd, $pos, [switch]$Right) {
  $rect = Get-WindowRect $hWnd
  Click-At ($rect.Left + [int]$pos.x) ($rect.Top + [int]$pos.y) -Right:$Right
}

function Type-Into($hWnd, $pos, $text) {
  Click-Rel $hWnd $pos
  [System.Windows.Forms.SendKeys]::SendWait("^a")
  Start-Sleep -Milliseconds 100
  [System.Windows.Forms.Clipboard]::SetText([string]$text)
  Start-Sleep -Milliseconds 80
  [System.Windows.Forms.SendKeys]::SendWait("^v")
  Start-Sleep -Milliseconds 80
  [System.Windows.Forms.SendKeys]::SendWait("{ENTER}")
  Start-Sleep -Milliseconds 150
}

function Format-Month($month) {
  $clean = ([string]$month).Trim()
  if ($clean -match "^\d$") { return "0$clean" }
  return $clean
}

function Select-MonthDropdown($hWnd, $pos, $month) {
  $targetMonth = Format-Month $month
  $monthNumber = [int]$targetMonth
  Click-Rel $hWnd $pos
  Start-Sleep -Milliseconds 300

  # HELIOS 월 콤보박스는 목록 좌표가 화면 배율/위치에 따라 흔들립니다.
  # 그래서 목록을 연 뒤 키보드로 01부터 선택 월까지 이동하고 Enter로 확정합니다.
  [System.Windows.Forms.SendKeys]::SendWait("{HOME}")
  Start-Sleep -Milliseconds 80
  for ($i = 1; $i -lt $monthNumber; $i++) {
    [System.Windows.Forms.SendKeys]::SendWait("{DOWN}")
    Start-Sleep -Milliseconds 35
  }
  [System.Windows.Forms.SendKeys]::SendWait("{ENTER}")
  Start-Sleep -Milliseconds 180
}

function Select-TplDepartments($hWnd, $menu, $statusLabel) {
  $statusLabel.Text = "부서 팝업 선택 중..."
  $form.Refresh()
  if ($menu -eq "other") {
    Click-Rel $hWnd (Get-Pos $menu "deptBlank")
    Start-Sleep -Milliseconds 150
    Click-Rel $hWnd (Get-Pos $menu "deptSearch")
    Start-Sleep -Milliseconds 120
    Click-Rel $hWnd (Get-Pos $menu "deptSearch")
  } else {
    Click-Rel $hWnd (Get-Pos $menu "deptSearch")
  }
  Start-Sleep -Milliseconds 450

  Click-Rel $hWnd (Get-Pos $menu "deptFirstCheck")
  Start-Sleep -Milliseconds 120
  [System.Windows.Forms.SendKeys]::SendWait(" ")
  Start-Sleep -Milliseconds 120

  $downCount = if ($menu -eq "other") { 10 } else { 37 }
  for ($i = 0; $i -lt $downCount; $i++) {
    [System.Windows.Forms.SendKeys]::SendWait("{DOWN}")
    Start-Sleep -Milliseconds 35
  }
  [System.Windows.Forms.SendKeys]::SendWait(" ")
  Start-Sleep -Milliseconds 100
  [System.Windows.Forms.SendKeys]::SendWait("{DOWN}")
  Start-Sleep -Milliseconds 60
  [System.Windows.Forms.SendKeys]::SendWait(" ")
  Start-Sleep -Milliseconds 100
  [System.Windows.Forms.SendKeys]::SendWait("{DOWN}")
  Start-Sleep -Milliseconds 60
  [System.Windows.Forms.SendKeys]::SendWait(" ")
  Start-Sleep -Milliseconds 120

  Click-Rel $hWnd (Get-Pos $menu "deptPopupClose")
  Start-Sleep -Milliseconds 300
}

function Capture-Point($key, $label, $statusLabel) {
  $menu = Menu-Key
  $menuLabel = if ($menu -eq "other") { "매출(기타)" } else { "매출" }
  $statusLabel.Text = "[$menuLabel] $label 위치 저장 준비: 3초 안에 HELIOS의 해당 위치에 마우스를 올려주세요."
  $form.Refresh()
  $hWnd = Focus-Helios
  Start-Sleep -Seconds 3
  $rect = Get-WindowRect $hWnd
  $cursor = [System.Windows.Forms.Cursor]::Position
  $pos = @{ x = $cursor.X - $rect.Left; y = $cursor.Y - $rect.Top }
  Set-Pos $menu $key $pos
  $statusLabel.Text = "[$menuLabel] $label 위치 저장 완료: x=$($pos.x), y=$($pos.y)"
}

function Capture-ExportOrgPoint($statusLabel) {
  $menu = Menu-Key
  $menuLabel = if ($menu -eq "other") { "매출(기타)" } else { "매출" }
  $statusLabel.Text = "[$menuLabel] Export(Org) 위치 저장 준비: 목록 위치를 우클릭한 뒤 3초 안에 Export(Org)에 마우스를 올려주세요."
  $form.Refresh()
  $hWnd = Focus-Helios
  Click-Rel $hWnd (Get-Pos $menu "grid") -Right
  Start-Sleep -Seconds 3
  $rect = Get-WindowRect $hWnd
  $cursor = [System.Windows.Forms.Cursor]::Position
  $pos = @{ x = $cursor.X - $rect.Left; y = $cursor.Y - $rect.Top }
  Set-Pos $menu "exportOrg" $pos
  $statusLabel.Text = "[$menuLabel] Export(Org) 위치 저장 완료: x=$($pos.x), y=$($pos.y)"
}

function Run-Download($menu, $month, $statusLabel) {
  try {
    $hWnd = Focus-Helios
    $statusLabel.Text = "HELIOS 입력 중..."
    $form.Refresh()

    $targetMonth = Format-Month $month
    Select-MonthDropdown $hWnd (Get-Pos $menu "monthStart") $targetMonth
    if ($menu -eq "sales") {
      Select-MonthDropdown $hWnd (Get-Pos $menu "monthEnd") $targetMonth
    }
    Select-TplDepartments $hWnd $menu $statusLabel

    $statusLabel.Text = "조회 실행 중..."
    $form.Refresh()
    Click-Rel $hWnd (Get-Pos $menu "search")
    Start-Sleep -Seconds 3

    $statusLabel.Text = "Export(Org) 실행 중..."
    $form.Refresh()
    Click-Rel $hWnd (Get-Pos $menu "grid") -Right
    Start-Sleep -Milliseconds 500
    Click-Rel $hWnd (Get-Pos $menu "exportOrg")

    $statusLabel.Text = "Export(Org) 클릭 완료. 엑셀 파일이 열리는지 확인해주세요."
    [System.Windows.Forms.MessageBox]::Show("Export(Org) 클릭까지 완료했습니다.`n엑셀 파일이 열리는지 확인해주세요.", "HELIOS 다운로드 도우미") | Out-Null
  } catch {
    $statusLabel.Text = "오류: $($_.Exception.Message)"
    [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, "오류") | Out-Null
  }
}

$config = Load-Config

$form = New-Object System.Windows.Forms.Form
$form.Text = "HELIOS 다운로드 도우미 v12"
$form.Size = New-Object System.Drawing.Size(620, 635)
$form.StartPosition = "CenterScreen"
$form.Font = New-Object System.Drawing.Font("Malgun Gothic", 9)

$title = New-Object System.Windows.Forms.Label
$title.Text = "HELIOS 다운로드 도우미 v12"
$title.Font = New-Object System.Drawing.Font("Malgun Gothic", 15, [System.Drawing.FontStyle]::Bold)
$title.Location = New-Object System.Drawing.Point(18, 16)
$title.Size = New-Object System.Drawing.Size(500, 32)
$form.Controls.Add($title)

$desc = New-Object System.Windows.Forms.Label
$desc.Text = "HELIOS 매출 화면을 열어둔 뒤 실행하세요. 월을 드롭박스로 선택하고, 부서 팝업에서 지정 위치 3개를 체크한 뒤 Export(Org)를 실행합니다."
$desc.Location = New-Object System.Drawing.Point(20, 52)
$desc.Size = New-Object System.Drawing.Size(560, 42)
$form.Controls.Add($desc)

$lblMenu = New-Object System.Windows.Forms.Label
$lblMenu.Text = "추출 메뉴"
$lblMenu.Location = New-Object System.Drawing.Point(22, 104)
$lblMenu.Size = New-Object System.Drawing.Size(90, 24)
$form.Controls.Add($lblMenu)

$menuBox = New-Object System.Windows.Forms.ComboBox
$menuBox.DropDownStyle = "DropDownList"
$menuBox.Items.Add("매출") | Out-Null
$menuBox.Items.Add("매출(기타)") | Out-Null
$menuBox.SelectedIndex = if ($InitialMenu -eq "other" -or $InitialMenu -eq "salesOther") { 1 } else { 0 }
$menuBox.Location = New-Object System.Drawing.Point(120, 100)
$menuBox.Size = New-Object System.Drawing.Size(160, 26)
$form.Controls.Add($menuBox)

$lblMonth = New-Object System.Windows.Forms.Label
$lblMonth.Text = "월"
$lblMonth.Location = New-Object System.Drawing.Point(22, 142)
$lblMonth.Size = New-Object System.Drawing.Size(90, 24)
$form.Controls.Add($lblMonth)

$monthBox = New-Object System.Windows.Forms.ComboBox
$monthBox.DropDownStyle = "DropDownList"
1..12 | ForEach-Object { $monthBox.Items.Add(("{0:D2}" -f $_)) | Out-Null }
$monthBox.SelectedItem = $InitialMonth
$monthBox.Location = New-Object System.Drawing.Point(120, 138)
$monthBox.Size = New-Object System.Drawing.Size(160, 26)
$form.Controls.Add($monthBox)

$runBtn = New-Object System.Windows.Forms.Button
$runBtn.Text = "HELIOS 다운로드 실행"
$runBtn.Location = New-Object System.Drawing.Point(305, 100)
$runBtn.Size = New-Object System.Drawing.Size(210, 64)
$runBtn.BackColor = [System.Drawing.Color]::FromArgb(18, 31, 42)
$runBtn.ForeColor = [System.Drawing.Color]::White
$runBtn.Add_Click({
  $menu = if ($menuBox.SelectedItem -eq "매출(기타)") { "other" } else { "sales" }
  Run-Download $menu $monthBox.Text $status
})
$form.Controls.Add($runBtn)

$focusBtn = New-Object System.Windows.Forms.Button
$focusBtn.Text = "HELIOS 창 앞으로"
$focusBtn.Location = New-Object System.Drawing.Point(305, 176)
$focusBtn.Size = New-Object System.Drawing.Size(210, 34)
$focusBtn.Add_Click({
  try { Focus-Helios | Out-Null; $status.Text = "HELIOS 창을 앞으로 가져왔습니다." } catch { $status.Text = $_.Exception.Message }
})
$form.Controls.Add($focusBtn)

$calTitle = New-Object System.Windows.Forms.Label
$calTitle.Text = "위치 보정"
$calTitle.Font = New-Object System.Drawing.Font("Malgun Gothic", 11, [System.Drawing.FontStyle]::Bold)
$calTitle.Location = New-Object System.Drawing.Point(22, 236)
$calTitle.Size = New-Object System.Drawing.Size(160, 24)
$form.Controls.Add($calTitle)

$calDesc = New-Object System.Windows.Forms.Label
$calDesc.Text = "버튼을 누른 뒤 3초 안에 HELIOS의 해당 위치에 마우스를 올려두면 좌표가 저장됩니다. Export(Org)는 목록 우클릭 후 메뉴 위치를 저장합니다."
$calDesc.Location = New-Object System.Drawing.Point(22, 262)
$calDesc.Size = New-Object System.Drawing.Size(560, 38)
$form.Controls.Add($calDesc)

$status = New-Object System.Windows.Forms.Label
$status.Text = "대기 중"
$status.BorderStyle = "FixedSingle"
$status.Location = New-Object System.Drawing.Point(22, 505)
$status.Size = New-Object System.Drawing.Size(560, 28)
$status.TextAlign = "MiddleLeft"
$form.Controls.Add($status)

$calibrationControls = New-Object System.Collections.ArrayList

function Calibration-Buttons($menu) {
  if ($menu -eq "other") {
    return @(
      @{ key="monthStart"; label="월 칸" },
      @{ key="deptBlank"; label="부서 빈칸" },
      @{ key="deptSearch"; label="부서 돋보기" },
      @{ key="deptFirstCheck"; label="09 체크박스" },
      @{ key="deptPopupClose"; label="부서 팝업 X" },
      @{ key="search"; label="조회 버튼" },
      @{ key="grid"; label="목록 우클릭 위치" }
    )
  }
  return @(
    @{ key="monthStart"; label="시작 월 칸" },
    @{ key="monthEnd"; label="종료 월 칸" },
    @{ key="deptSearch"; label="부서 돋보기" },
    @{ key="deptFirstCheck"; label="09 체크박스" },
    @{ key="deptPopupClose"; label="부서 팝업 X" },
    @{ key="search"; label="조회 버튼" },
    @{ key="grid"; label="목록 우클릭 위치" }
  )
}

function Render-CalibrationButtons {
  foreach ($control in @($calibrationControls)) {
    $form.Controls.Remove($control)
    $control.Dispose()
  }
  $calibrationControls.Clear()

  $menu = Menu-Key
  $menuLabel = if ($menu -eq "other") { "매출(기타)" } else { "매출" }
  $calTitle.Text = "위치 보정 - $menuLabel"
  $calDesc.Text = "현재 선택된 추출 메뉴($menuLabel)에 맞는 좌표만 저장합니다. Export(Org)는 목록 우클릭 후 메뉴 위치를 저장합니다."

  $buttons = Calibration-Buttons $menu
  for ($i = 0; $i -lt $buttons.Count; $i++) {
    $b = $buttons[$i]
    $btn = New-Object System.Windows.Forms.Button
    $btn.Text = "$($b.label) 저장"
    $btn.Location = New-Object System.Drawing.Point((22 + (($i % 2) * 285)), (313 + ([math]::Floor($i / 2) * 36)))
    $btn.Size = New-Object System.Drawing.Size(260, 30)
    $key = $b.key
    $label = $b.label
    $btn.Add_Click({ Capture-Point $key $label $status }.GetNewClosure())
    $form.Controls.Add($btn)
    [void]$calibrationControls.Add($btn)
  }

  $exportRow = [math]::Ceiling($buttons.Count / 2)
  $exportBtn = New-Object System.Windows.Forms.Button
  $exportBtn.Text = "Export(Org) 메뉴 저장"
  $exportBtn.Location = New-Object System.Drawing.Point(22, (313 + ($exportRow * 36)))
  $exportBtn.Size = New-Object System.Drawing.Size(260, 30)
  $exportBtn.Add_Click({ Capture-ExportOrgPoint $status })
  $form.Controls.Add($exportBtn)
  [void]$calibrationControls.Add($exportBtn)
}

$menuBox.Add_SelectedIndexChanged({
  Render-CalibrationButtons
  $status.Text = "추출 메뉴가 변경되었습니다. 현재 메뉴 기준으로 위치를 저장해주세요."
})

Render-CalibrationButtons

[void]$form.ShowDialog()
