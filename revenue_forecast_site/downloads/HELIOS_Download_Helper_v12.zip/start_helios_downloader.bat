@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0helios_downloader.ps1"

