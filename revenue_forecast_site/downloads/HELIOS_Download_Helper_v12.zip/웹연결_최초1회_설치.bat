@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0register_web_protocol.ps1"
