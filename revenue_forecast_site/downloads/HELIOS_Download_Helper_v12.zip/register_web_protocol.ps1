﻿Add-Type -AssemblyName System.Windows.Forms

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$HelperPath = Join-Path $ScriptDir "helios_downloader.ps1"
$ProtocolRoot = "HKCU:\Software\Classes\hanexhelios"
$CommandPath = Join-Path $ProtocolRoot "shell\open\command"
$Command = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$HelperPath`" `"%1`""

New-Item -Path $ProtocolRoot -Force | Out-Null
Set-Item -Path $ProtocolRoot -Value "URL:HanExpress HELIOS Downloader"
New-ItemProperty -Path $ProtocolRoot -Name "URL Protocol" -Value "" -PropertyType String -Force | Out-Null
New-Item -Path $CommandPath -Force | Out-Null
Set-Item -Path $CommandPath -Value $Command

[System.Windows.Forms.MessageBox]::Show(
  "웹페이지와 HELIOS 다운로드 도우미 연결이 완료되었습니다.`n이제 웹페이지의 다운로드 실행 버튼을 사용할 수 있습니다.",
  "연결 설치 완료"
) | Out-Null
